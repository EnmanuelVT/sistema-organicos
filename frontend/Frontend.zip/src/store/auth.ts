// src/store/auth.ts
import { create } from 'zustand';
import { login as apiLogin, getCurrentUser as apiGetCurrentUser } from '../api/auth';
import { normalizeRole } from '../utils/roles';

const TOKEN_KEY = import.meta.env.VITE_TOKEN_STORAGE_KEY || 'accessToken';
const REFRESH_KEY = import.meta.env.VITE_REFRESH_TOKEN_STORAGE_KEY || 'refreshToken';

type User = { id: string; email: string; role: string; roleNorm?: ReturnType<typeof normalizeRole> };


interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  role: string | null;
  setUser: (u: User) => void;
  login: (email: string, password: string) => Promise<void>;
  getCurrentUser: () => Promise<void>;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: !!localStorage.getItem(TOKEN_KEY),
  role: null,

  setUser: (u) => set({ user: { ...u, roleNorm: normalizeRole(u.role) }, role: normalizeRole(u.role) }),

  login: async (email, password) => {
    await apiLogin(email, password);
    await (async () => {
      try {
        const me = await apiGetCurrentUser();
        set({ user: { ...me, roleNorm: normalizeRole(me.role) }, isAuthenticated: true, role: normalizeRole(me.role) });
        // Redirección siempre al panel principal
        window.location.href = '/';
      } catch {
        set({ user: null, isAuthenticated: false, role: null });
      }
    })();
  },

  getCurrentUser: async () => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (!token) { set({ user: null, isAuthenticated: false, role: null }); return; }
    const me = await apiGetCurrentUser();
    set({ user: { ...me, roleNorm: normalizeRole(me.role) }, isAuthenticated: true, role: normalizeRole(me.role) });
  },

  logout: () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(REFRESH_KEY);
    set({ user: null, isAuthenticated: false, role: null });
    window.location.href = '/login';
  },
}));

// bootstrap al arrancar si hay token
if (localStorage.getItem(TOKEN_KEY)) {
  useAuthStore.getState().getCurrentUser().catch(() => {});
}
