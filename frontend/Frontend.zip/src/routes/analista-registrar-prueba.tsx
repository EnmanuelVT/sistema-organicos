import { useParams, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { getParametrosByTipoMuestra, registrarPrueba } from '../api/ensayos'
import { toNum } from '../utils/coerce'

type ParametroInput = { idParametro: number; valorObtenido: number }

export default function AnalistaRegistrarPrueba() {
  const { mstCodigo = '' } = useParams()
  const nav = useNavigate()

  // Estados del formulario
  const [nombrePrueba, setNombrePrueba] = useState('Análisis X')
  const [tipoMuestraAsociada, setTipoMuestraAsociada] = useState<number>(1)

  // Manejo de parámetros a enviar
  const [parametros, setParametros] = useState<ParametroInput[]>([])
  const [idParam, setIdParam] = useState<number>(1)
  const [valor, setValor] = useState<number>(0)

  // Para sugerir/validar parámetros según tipo de muestra (opcional)
  const { data: paramDefs } = useQuery({
    queryKey: ['parametros', tipoMuestraAsociada],
    queryFn: () => getParametrosByTipoMuestra(tipoMuestraAsociada),
  })

  const { mutateAsync, isPending } = useMutation({
    mutationFn: registrarPrueba,
    onSuccess: () => nav('/analista/mis-muestras') // ajusta la ruta según tu router
  })

  const addParametro = () => {
    const id = toNum(idParam)!
    const val = toNum(valor)!
    if (!id || Number.isNaN(id) || Number.isNaN(val)) return
    setParametros((prev) => [...prev, { idParametro: id, valorObtenido: val }])
    setIdParam(1)
    setValor(0)
  }

  const removeParametro = (index: number) => {
    setParametros((prev) => prev.filter((_, i) => i !== index))
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!mstCodigo) return

    const payload = {
      mstCodigo,
      nombrePrueba,
      tipoMuestraAsociada: toNum(tipoMuestraAsociada)!,
      parametros: parametros.map(p => ({
        idParametro: toNum(p.idParametro)!,
        valorObtenido: toNum(p.valorObtenido)!,
      })),
    }

    await mutateAsync(payload as any)
  }

  return (
    <div className="mx-auto max-w-3xl p-6">
      <h1 className="mb-4 text-2xl font-semibold">Registrar prueba</h1>

      <form onSubmit={submit} className="space-y-6">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <Text label="Código de muestra">
            <input className="input" value={mstCodigo} disabled />
          </Text>

          <Text label="Tipo de muestra (ID)">
            <input
              className="input"
              type="number"
              value={tipoMuestraAsociada}
              onChange={(e) => setTipoMuestraAsociada(Number(e.target.value))}
            />
          </Text>

          <Text label="Nombre de la prueba">
            <input
              className="input"
              value={nombrePrueba}
              onChange={(e) => setNombrePrueba(e.target.value)}
            />
          </Text>
        </div>

        <div className="rounded border p-4">
          <div className="mb-3 font-medium">Parámetros</div>

          <div className="mb-3 grid grid-cols-1 gap-3 md:grid-cols-3">
            <Text label="ID Parámetro">
              <input
                className="input"
                type="number"
                value={idParam}
                onChange={(e) => setIdParam(Number(e.target.value))}
                list="param-defs"
              />
              {/* Sugerencias de parámetros según tipo (opcional) */}
              {paramDefs?.length ? (
                <datalist id="param-defs">
                  {paramDefs.map((p: any) => (
                    <option key={p.idParametro} value={p.idParametro}>
                      {p.nombreParametro} ({p.valorMin} - {p.valorMax})
                    </option>
                  ))}
                </datalist>
              ) : null}
            </Text>

            <Text label="Valor obtenido">
              <input
                className="input"
                type="number"
                step="any"
                value={valor}
                onChange={(e) => setValor(Number(e.target.value))}
              />
            </Text>

            <div className="flex items-end">
              <button type="button" onClick={addParametro} className="w-full rounded border px-4 py-2">
                Agregar
              </button>
            </div>
          </div>

          <ul className="space-y-2">
            {parametros.map((p, i) => (
              <li key={`${p.idParametro}-${i}`} className="flex items-center justify-between rounded border p-2 text-sm">
                <span>Param #{p.idParametro}: {p.valorObtenido}</span>
                <button type="button" onClick={() => removeParametro(i)} className="text-red-600 underline">
                  Quitar
                </button>
              </li>
            ))}
            {!parametros.length && <li className="text-xs text-gray-500">No has agregado parámetros.</li>}
          </ul>
        </div>

        <div className="flex justify-end gap-3">
          <button type="button" onClick={() => history.back()} className="rounded border px-4 py-2">
            Cancelar
          </button>
          <button disabled={isPending} className="rounded bg-black px-4 py-2 text-white">
            {isPending ? 'Guardando…' : 'Guardar'}
          </button>
        </div>
      </form>

      <style>{`.input{width:100%; @apply rounded border px-3 py-2}`}</style>
    </div>
  )
}

function Text({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <label className="text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      {children}
      {error && <span className="mt-1 block text-xs text-red-600">{error}</span>}
    </label>
  )
}
