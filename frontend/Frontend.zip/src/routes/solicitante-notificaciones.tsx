export default function SolicitanteNotificaciones() {
  return (
    <div className='rounded-xl border bg-white p-6'>
      <h1 className='mb-2 text-xl font-semibold'>Notificaciones</h1>
      <p className='text-sm text-slate-600'>Aquí verás alertas del sistema (demo).</p>
    </div>
  )
}
