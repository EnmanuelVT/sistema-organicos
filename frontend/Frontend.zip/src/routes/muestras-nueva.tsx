import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { createMuestra } from '../api/muestras'
import { useNavigate } from 'react-router-dom'
import { toIso } from '../utils/coerce'

const schema = z.object({
  mstCodigo: z.string().min(2, 'Código requerido'),
  tpmstId: z.number({ required_error: 'Tipo de muestra requerido' }).min(1, 'Tipo de muestra requerido'),
  nombre: z.string().min(1, 'Nombre requerido'),
  origen: z.string().min(1, 'Origen requerido'),
  condicionesAlmacenamiento: z.string().optional().or(z.literal('')),
  condicionesTransporte: z.string().optional().or(z.literal('')),
  fechaRecepcion: z.string().min(1, 'Fecha requerida'),
})

type FormValues = z.infer<typeof schema>

export default function MuestrasNueva() {
  const nav = useNavigate()
  const qc = useQueryClient()

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      mstCodigo: '',
      tpmstId: 1,
      nombre: '',
      origen: '',
      condicionesAlmacenamiento: '',
      condicionesTransporte: '',
      fechaRecepcion: new Date().toISOString().slice(0, 10), // yyyy-mm-dd
    }
  })

  const { mutateAsync } = useMutation({
    mutationFn: createMuestra,
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['muestras'] })
    }
  })

  const onSubmit = async (data: FormValues) => {
    // Construir payload exactamente como lo espera el backend
    const payload = {
      mstCodigo: data.mstCodigo,
      tpmstId: data.tpmstId, // gracias a valueAsNumber ya es number
      nombre: data.nombre,
      origen: data.origen,
      condicionesAlmacenamiento: data.condicionesAlmacenamiento || undefined,
      condicionesTransporte: data.condicionesTransporte || undefined,
      fechaRecepcion: toIso(data.fechaRecepcion), // ISO string para DateTime del backend
    }
    await mutateAsync(payload as any)
    nav('/muestras') // redirige al listado de muestras (ajusta si tu ruta difiere)
  }

  return (
    <div className="mx-auto max-w-3xl p-6">
      <h1 className="mb-4 text-2xl font-semibold">Registrar nueva muestra</h1>

      <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <Text label="Código de Muestra" error={errors.mstCodigo?.message}>
          <input className="input" {...register('mstCodigo')} />
        </Text>

        <Text label="Tipo de Muestra (ID)" error={errors.tpmstId?.message}>
          <input className="input" type="number" {...register('tpmstId', { valueAsNumber: true })} />
        </Text>

        <Text label="Nombre" error={errors.nombre?.message}>
          <input className="input" {...register('nombre')} />
        </Text>

        <Text label="Origen" error={errors.origen?.message}>
          <input className="input" {...register('origen')} />
        </Text>

        <Text label="Condiciones de almacenamiento" error={errors.condicionesAlmacenamiento?.message}>
          <input className="input" {...register('condicionesAlmacenamiento')} />
        </Text>

        <Text label="Condiciones de transporte" error={errors.condicionesTransporte?.message}>
          <input className="input" {...register('condicionesTransporte')} />
        </Text>

        <Text label="Fecha de recepción" error={errors.fechaRecepcion?.message}>
          <input className="input" type="date" {...register('fechaRecepcion')} />
        </Text>

        <div className="col-span-full flex justify-end gap-3 pt-2">
          <button type="button" onClick={() => history.back()} className="rounded border px-4 py-2">
            Cancelar
          </button>
          <button disabled={isSubmitting} className="rounded bg-black px-4 py-2 text-white">
            {isSubmitting ? 'Guardando…' : 'Guardar'}
          </button>
        </div>
      </form>

      <style>{`.input{width:100%; @apply rounded border px-3 py-2}`}</style>
    </div>
  )
}

function Text({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <label className="text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      {children}
      {error && <span className="mt-1 block text-xs text-red-600">{error}</span>}
    </label>
  )
}
