// src/api/ensayos.ts
import api from './apiClient'
import type { ParametroDto, CreatePruebaDto, PruebaDto } from '../types/domain'

/* ===== Básicas ===== */

export async function getParametrosByTipoMuestra(tipoMuestraId: number) {
  const { data } = await api.get(`/api/parametro/tipo-muestra/${tipoMuestraId}`)
  return data as ParametroDto[]
}

export async function registrarPrueba(payload: CreatePruebaDto) {
  const { data } = await api.post('/api/pruebas', payload)
  return data as PruebaDto
}

/* ===== Resultados / Pruebas por muestra =====
   Algunas pantallas piden getResultadosByMuestra(mstCodigo).
   Intentamos el endpoint más probable y caemos a alternativas seguras. */

export async function getResultadosByMuestra(mstCodigo: string) {
  // 1) /api/pruebas/muestra/{mstCodigo}
  try {
    const { data } = await api.get(`/api/pruebas/muestra/${encodeURIComponent(mstCodigo)}`)
    return data as PruebaDto[]
  } catch {}

  // 2) /api/muestras/{mstCodigo}/pruebas
  try {
    const { data } = await api.get(`/api/muestras/${encodeURIComponent(mstCodigo)}/pruebas`)
    return data as PruebaDto[]
  } catch {}

  // 3) /api/pruebas?mstCodigo=...
  try {
    const { data } = await api.get(`/api/pruebas`, { params: { mstCodigo } })
    return data as PruebaDto[]
  } catch {}

  // Si nada existe aún, devolvemos arreglo vacío para no romper la UI
  return [] as PruebaDto[]
}

/* ===== Aliases de compatibilidad (nombres alternativos) ===== */
export const getParamsBySampleType = getParametrosByTipoMuestra
export const getParametrosDeTipoMuestra = getParametrosByTipoMuestra
export const registerTest = registrarPrueba
export const registerEnsayo = registrarPrueba

export const getResultadosDeMuestra = getResultadosByMuestra
export const getPruebasByMuestra = getResultadosByMuestra
