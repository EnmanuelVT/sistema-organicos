// src/api/muestras.ts
import api from './apiClient';
import type {
  MuestraDto,
  CreateMuestraDto,
  AsignarAnalistaEnMuestraDto,
  AsignarEvaluadorEnMuestraDto,
  CambiarEstadoMuestraDto,
  EvaluarMuestraDto,
} from '../types/domain';

/* ============================
 *        ENDPOINTS BASE
 * ============================ */

export async function getAllMuestras() {
  const { data } = await api.get('/api/muestras');
  return data as MuestraDto[];
}

export async function getMyMuestras() {
  const { data } = await api.get('/api/muestras/me');
  return data as MuestraDto[];
}

export async function getMuestraByCodigo(mstCodigo: string) {
  const { data } = await api.get(`/api/muestras/${encodeURIComponent(mstCodigo)}`);
  return data as MuestraDto;
}

export async function createMuestra(payload: CreateMuestraDto) {
  const { data } = await api.post('/api/muestras', payload);
  return data as MuestraDto;
}

export async function assignAnalista(dto: AsignarAnalistaEnMuestraDto) {
  const { data } = await api.post('/api/muestras/asignar-analista', dto);
  return data;
}

export async function assignEvaluador(dto: AsignarEvaluadorEnMuestraDto) {
  const { data } = await api.post('/api/muestras/asignar-evaluador', dto);
  return data;
}

export async function evaluarMuestra(dto: EvaluarMuestraDto) {
  const { data } = await api.post('/api/muestras/evaluar', dto);
  return data;
}

export async function cambiarEstado(dto: CambiarEstadoMuestraDto) {
  const { data } = await api.post('/api/muestras/cambiar-estado', dto);
  return data;
}

/* ==========================================
 *  CAPA DE COMPATIBILIDAD (ALIAS/NOMBRES)
 *  Evita romper pantallas existentes
 * ========================================== */

// Admin (analista/evaluador)
export async function assignAnalystToMuestra(input: {
  mstCodigo: string;
  idAnalista: string;
  observaciones?: string;
}) {
  const dto: AsignarAnalistaEnMuestraDto = {
    mstCodigo: input.mstCodigo,
    analistaId: input.idAnalista,
  };
  return assignAnalista(dto);
}

export async function assignEvaluatorToMuestra(input: {
  mstCodigo: string;
  idEvaluador: string;
  observaciones?: string;
}) {
  const dto: AsignarEvaluadorEnMuestraDto = {
    mstCodigo: input.mstCodigo,
    evaluadorId: input.idEvaluador,
  };
  return assignEvaluador(dto);
}

// Analista (mis asignadas)
export async function getMyAssignedMuestras() {
  return getMyMuestras();
}

// Evaluador (revisar/evaluar)
export function evaluateMuestra(dto: EvaluarMuestraDto) {
  return evaluarMuestra(dto);
}

// Cambios de estado con nombres alternativos
export function changeMuestraStatus(dto: CambiarEstadoMuestraDto) {
  return cambiarEstado(dto);
}
export function changeStatus(dto: CambiarEstadoMuestraDto) {
  return cambiarEstado(dto);
}

// —— NUEVOS ALIAS para detalle por id (lo que pide tu pantalla) ——
export async function getMuestraById(id: string) {
  // En tu dominio el “id” es el mstCodigo
  return getMuestraByCodigo(id);
}
// variantes comunes que a veces aparecen en pantallas:
export async function getMuestra(id: string) {
  return getMuestraByCodigo(id);
}
export async function getMuestraDetalle(id: string) {
  return getMuestraByCodigo(id);
}

/* ===== Utilidades por rol (si no hay endpoints dedicados, filtra cliente) ===== */

export async function getMuestrasByAnalyst(analistaId: string) {
  try {
    const { data } = await api.get(`/api/muestras/analista/${encodeURIComponent(analistaId)}`);
    return data as MuestraDto[];
  } catch {
    const all = await getAllMuestras();
    return all.filter((m: any) => m.analistaId === analistaId);
  }
}

export async function getMuestrasByEvaluador(evaluadorId: string) {
  try {
    const { data } = await api.get(`/api/muestras/evaluador/${encodeURIComponent(evaluadorId)}`);
    return data as MuestraDto[];
  } catch {
    const all = await getAllMuestras();
    return all.filter((m: any) => m.evaluadorId === evaluadorId);
  }
}

export async function getMuestrasByUser(solicitanteId: string) {
  try {
    const { data } = await api.get(`/api/muestras/usuario/${encodeURIComponent(solicitanteId)}`);
    return data as MuestraDto[];
  } catch {
    const mine = await getMyMuestras();
    if (mine?.length) return mine;
    const all = await getAllMuestras();
    return all.filter((m: any) => m.solicitanteId === solicitanteId);
  }
}
