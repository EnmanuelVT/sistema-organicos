// src/api/documentos.ts
import api from './apiClient';

export async function descargarCertificado(mstCodigo: string) {
  const res = await api.get(`/api/documentos/${encodeURIComponent(mstCodigo)}/certificado`, {
    responseType: 'blob',
  });
  const blob = new Blob([res.data], { type: res.headers['content-type'] || 'application/pdf' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const cd = res.headers['content-disposition'] as string | undefined;
  const fallback = `certificado-${mstCodigo}.pdf`;
  const filename = cd?.match(/filename="?([^"]+)"?/)?.[1] || fallback;
  a.download = filename;
  a.click();
  window.URL.revokeObjectURL(url);
}
/* ===== Compat (nombres alternativos) ===== */
export const downloadCertificate = descargarCertificado;
export const getCertificado = descargarCertificado;
export const descargar = descargarCertificado;

