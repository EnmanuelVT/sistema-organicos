// src/api/users.ts
import api from './apiClient'
import type { UserDto } from '../types/domain'

interface CreateUserDto {
  userName: string;
  email: string;
  role: string;
  usCedula?: string;
  nombre?: string;
  apellido?: string;
  password?: string;
}

// Lista de usuarios (admin)
export async function getAllUsers() {
  try {
    const { data } = await api.get('/api/admin/users')
    return data as UserDto[]
  } catch {
    const { data } = await api.get('/api/usuarios')
    return data as UserDto[]
  }
}

// Crear
export async function createUser(payload: CreateUserDto) {
  try {
    const { data } = await api.post('/api/admin/users', payload)
    return data as UserDto
  } catch {
    const { data } = await api.post('/api/usuarios', payload)
    return data as UserDto
  }
}

// Actualizar
export async function updateUser(payload: UserDto) {
  try {
    const { data } = await api.put(`/api/admin/users/${payload.id}`, payload)
    return data
  } catch {
    const { data } = await api.put(`/api/usuarios/${payload.id}`, payload)
    return data
  }
}

// Eliminar
export async function deleteUser(id: string) {
  try {
    const { data } = await api.delete(`/api/admin/users/${id}`)
    return data
  } catch {
    const { data } = await api.delete(`/api/usuarios/${id}`)
    return data
  }
}

// Usuario actual
export async function getCurrentUser() {
  const { data } = await api.get('/api/usuarios/me')
  return data as UserDto
}

/* ===== Compat (nombres alternativos) ===== */
export const getUsers = getAllUsers;
export const listUsers = getAllUsers;
