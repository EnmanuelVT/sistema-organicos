// src/api/auth.ts
import api from './apiClient';
import { normalizeRole } from '../utils/roles';

export type Role = 'ADMIN' | 'ANALISTA' | 'EVALUADOR' | 'SOLICITANTE';

interface LoginResponse {
  tokenType?: string;
  accessToken: string;
  expiresIn?: number;
  refreshToken?: string;
}

const AUTH_BASE = import.meta.env.VITE_AUTH_BASE_URL || import.meta.env.VITE_API_BASE_URL;
const TOKEN_KEY = import.meta.env.VITE_TOKEN_STORAGE_KEY || 'accessToken';
const REFRESH_KEY = import.meta.env.VITE_REFRESH_TOKEN_STORAGE_KEY || 'refreshToken';

export async function login(email: string, password: string) {
  const res = await fetch('http://localhost:5062/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', accept: 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  if (!res.ok) throw new Error(`Login failed: ${res.status}`);
  const data = (await res.json()) as LoginResponse;
  localStorage.setItem(TOKEN_KEY, data.accessToken);
  if (data.refreshToken) localStorage.setItem(REFRESH_KEY, data.refreshToken);
  return data;
}

export async function getCurrentUser() {
  // asume backend expone /api/usuarios/me devolviendo { id, email, role }
  const { data } = await api.get('/api/usuarios/me');
  // normaliza role al entrar
  return { ...data, role: normalizeRole(data.role) };
}

export async function forgotPassword(email: string) {
  const { data } = await api.post('/forgotPassword', { email });
  return data;
}

export async function resetPassword(email: string, resetCode: string, newPassword: string) {
  const { data } = await api.post('/resetPassword', { email, resetCode, newPassword });
  return data;
}
