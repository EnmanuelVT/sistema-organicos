// src/components/Protected.tsx
import { Navigate } from 'react-router-dom'
import { useAuthStore } from '../store/auth'
import { hasAnyRole, AppRole } from '../utils/roles'

export default function Protected({
  roles,
  children,
}: {
  roles?: AppRole[]
  children: JSX.Element
}) {
  const { token, role } = useAuthStore() as { token?: string | null; role?: string }

  // No autenticado -> login
  if (!token) return <Navigate to="/login" replace />

  // Si hay restricción de roles, validar
  if (roles && role && !hasAnyRole(role, roles)) {
    return (
      <div className="p-6 text-center text-sm text-red-600">
        No tienes permisos para ver esta sección.
      </div>
    )
  }

  return children
}
