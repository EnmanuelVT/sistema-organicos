# Frontend Trazabilidad (roles y flujo)
- 4 roles: SOLICITANTE, ANALISTA, EVALUADOR, ADMIN
- Flujo: solicitante registra → admin asigna → analista registra test → evaluador aprueba/rechaza (genera PDF simulado o devuelve con observaciones).

## Arranque
```bash
npm install
npm run dev
```
Abra http://localhost:5173

## Login
- Rol + userId (ej: sol-1, analista-1, eval-1)
