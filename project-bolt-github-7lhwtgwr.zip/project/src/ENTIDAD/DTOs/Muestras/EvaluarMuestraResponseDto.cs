using ENTIDAD.DTOs.Documentos;

namespace ENTIDAD.DTOs.Muestras;

public class EvaluarMuestraResponseDto
{
    public MuestraDto? Muestra { get; set; }
    public DocumentoDto? Documento { get; set; }
}
