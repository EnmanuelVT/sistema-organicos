namespace ENTIDAD.DTOs.Documentos;

public class GenerarPreliminarRequest
{
    public string? Observaciones { get; set; }
}